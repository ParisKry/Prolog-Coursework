/* **************************************
Fibonacci numbers. Two versions exist in the 
file. The one that "learns" is more efficient 
both in terms of execution and memory requirements.

File contains examples presented in class.
Author: Ilias Sakellariou 
Date: November 2002 Updated: November 2003
Updated: March 2013, ECliPSe Compatibility.
*********************************** */

%%% Needed for tell/told.
:-lib(cio).

%%% Dynamic declaration of fibonacci/2
%%% predicate, required for assert/retract 
%%% predicate calls.
:-dynamic fibonacci_lemma/2.

%%% fibonacci/2
%%% fibonacci(N,Result)
%%% Succeeds if Result is the 
%%% fibonacci number of N.

fibonacci(0,1).
fibonacci(1,1).
fibonacci(N,F):-
	N>1,
	N1 is N -1,
	N2 is N -2,
	fibonacci(N1,F1),
	fibonacci(N2,F2),
	F is F1+F2.




%%% fibonacci_lemma/2
%%% fibonacci_lemma(N,Result)
%%% Succeeds if Result is the 
%%% fibonacci number of N.
%%% Version uses lemma2 predicate to 
%%% learn fibonacci numbers.  
fibonacci_lemma(0,1).
fibonacci_lemma(1,1).
fibonacci_lemma(N,F):-
	N>1,
	N1 is N -1,
	N2 is N -2,
	lemma_once(fibonacci_lemma(N1,F1)),
	fibonacci_lemma(N2,F2),
	F is F1+F2.




%%% lemma/1
%%% lemma(Goal)
%%% Succeeds if Goal succeeds. The 
%%% predicate's side effect is that 
%%% it asserts the proven goal in 
%%% Prolog's database.  

lemma(Goal):-
	call(Goal),
	asserta(Goal).


%%% lemma_once/1
%%% lemma_once(Goal)
%%% Succeeds if Goal succeeds. If the
%%% proven Goal has not been learned before 
%%% it asserts it in Prolog's Database. 
%%% Better than lemma/1 since it asserts a 
%%% lemma if it does not exists in the database.

lemma_once(Goal):-
	call(Goal),
	(not( clause(Goal,!) )->
	           asserta((Goal:-!));true).


/* ******************************************
Suggestion: Alter the fibonacci_lemma version 
to use lemma/1 instead of lemma_once/1 to 
see what happens. 
Tip: Try asking for alternative answers.
************************************* */ 



save_learned_facts(File):-
		tell(File),
		clause(fibonacci_lemma(N,X),!),
		write(fibonacci_lemma(N,X)),write(':-!.'),nl,fail.

save_learned_facts(_):-told.


%%% save_facts/1
%%% save_facts(FileName)
%%% Saves all learned facts on fibonacci numbers in 
%%% a file name File, using builtin predicate listing. 

save_facts(File):-
	tell(File),
	listing(fibonacci_lemma/2),
	told.


%%% save_facts2/1
%%% save_facts2(FileName)
%%% Saves all learned facts on fibonacci numbers in 
%%% a file name File.

save_facts2(File):-
		tell(File),
		clause( fibonacci_lemma(N,X),Body ),
		%%numbervars( (fibonacci_lemma(N,X),Body),0,_),
		write( fibonacci_lemma(N,X) ),
		write(':-'),
		write(Body),
		write('.'),nl,fail.
save_facts2(_):-told.


	



