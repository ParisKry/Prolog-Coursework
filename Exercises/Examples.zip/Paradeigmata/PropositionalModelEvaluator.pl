
%%%% 
:-op(450,yfx,and).
:-op(500,yfx,or).
:-op(500,yfx,nor).
:-op(450,yfx,nand).
:-op(500,yfx,xor).

:-op(400,fy,--).
:-op(600,xfx,==>).



--Arg1:-not(Arg1).
 
Arg1 ==> Arg2 :- Arg1 or --Arg2.

Arg1 and Arg2 :- Arg1, Arg2.

Arg1 or _Arg2 :- Arg1.
_Arg1 or Arg2 :-Arg2.

Arg1 xor Arg2 :- Arg1, --Arg2.
Arg1 xor Arg2 :- --Arg1, Arg2.

Arg1 nor Arg2 :- --(Arg1 or Arg2).
Arg1 nand Arg2 :- --(Arg1 and Arg2).


t. 
f:-!,fail.

%%% A model evaluator
model(Expr):-
   term_variables(Expr,List),
   assign_tf(List),
   Expr.

assign_tf([]).
assign_tf([t|Rest]):-
	assign_tf(Rest).
assign_tf([f|Rest]):-
	assign_tf(Rest). 	


%%% Theory
theory([]).
theory([Axiom|Rest]):-
	model(Axiom),
	theory(Rest). 
