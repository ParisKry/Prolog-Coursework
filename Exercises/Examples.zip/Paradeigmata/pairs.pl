pairs(X,Y):-
    member(X,[1,2,3,4,5,6,7,8,9,10]),
    member(Y,[1,2,3,4,5,6,7,8,9,10]),
    5 is X-Y,
    T is X+Y,
    T < 15. 
