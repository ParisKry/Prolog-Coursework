:-lib(ic).


solve_mill(A,B,C,D):-
	[A,B,C,D] #:: 1..4,
	A #\= B, A #\= C, A #\= D,
	B #\= C, B #\= D,
	C #\= D,

	A #> D, C #< B, B #< A, 

	%%labeling([A,B,C,D]).
	search([A,B,C,D],0,first_fail,indomain,complete,[]). 